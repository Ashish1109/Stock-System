﻿function validateEmail(email) {
    var reg = /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/
    if (reg.test(email)) {
        return true;
    } else {
        return false;
    }
}

function onlyAlphabets(e, t) {
    try {
        var charCode;
        if (window.event) {
            charCode = window.event.keyCode;
        } else if (e) {
            charCode = e.which;
        } else { return true; }
        if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123))
            return true;
        else
            return false;
    }
    catch (err) {
        alert(err.Description);
    }
    return true;
};

function onlyNos(e, t) {
    try {
        var charCode;
        if (window.event) {
            charCode = window.event.keyCode;
        } else if (e) {
            charCode = e.which;
        } else { return true; }
        if (charCode > 31 && (charCode < 48 || charCode > 57)) {
            return false;
        }
        return true;
    }
    catch (err) {
        alert(err.Description);
    }
    return true;
};

passwordValidation = function (e, t) {
    var charCode;
    try {
        if (window.event) {
            charCode = window.event.keyCode;
        } else if (e) {
            charCode = e.which;
        }
    } catch (err) {
        alert(err.Description);
    }
    return (onlyNos(e, t) || onlyAlphabets(e, t) || (charCode == 36 || charCode == 64)) ? true : false;
};