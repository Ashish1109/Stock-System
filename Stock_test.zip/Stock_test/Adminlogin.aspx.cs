﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Stock_test
{
    public partial class WebForm3 : System.Web.UI.Page
    {
       


        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            string user = txt_Userid.Text;
            string passwrd = txt_passwrd.Text;
            if (user == "Admin123" && passwrd == "dbproject")
            {
                Response.Redirect("Adminpage.aspx");
            }
            else
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "msgbox", "alert('Login Failed');", true);
            }
        }

        protected void btncancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("home.aspx");
        }
    }
    
}