﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Stock_test
{
    public partial class WebForm6 : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {

            string s = ConfigurationManager.AppSettings["constr"];
            con = new SqlConnection(s);
            con.Open();
        }
        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand("Check_Login_Details", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter da = new SqlDataAdapter();
                    // This will be your input parameter and its value


                    cmd.Parameters.Add("@Userid", SqlDbType.VarChar).Value = txt_Userid.Text;
                    cmd.Parameters.Add("@userpassword", SqlDbType.VarChar).Value = txt_passwrd.Text;


                    da.SelectCommand = cmd;
                    da.SelectCommand.CommandType = CommandType.StoredProcedure;

                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    String status = ds.Tables[0].Rows[0][0].ToString();


                    if (status == "LoginSuccessfull" || status == "ExistingUser")
                    {
                        if (status == "ExistingUser")
                        {
                            Session["check"] = "ExistingUser";
                        }
                        else
                        {
                            Session["check"] = "NewUser";
                        }
                        string amount = ds.Tables[0].Rows[0][1].ToString();
                        string accno = ds.Tables[0].Rows[0][2].ToString();
                        string Fname = ds.Tables[0].Rows[0][3].ToString();
                        Session["Acc_no"] = accno;
                        Session["Userid"] = txt_Userid.Text;
                        Session["Fname"] = Fname;
                        Session["amount"] = amount;
                        Page.ClientScript.RegisterStartupScript(GetType(), "msgbox", "alert('Login Successfull');", true);
                        Response.Redirect("TransactionPage.aspx");
                    }
                    else
                    {
                        Page.ClientScript.RegisterStartupScript(GetType(), "msgbox", "alert('Login Failed');", true);
                        txt_Userid.Text = "";
                        txt_passwrd.Text = "";
                    }


                }

            }

            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            con.Close();
        }

        protected void btncancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("home.aspx");
        }
    }

}