﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Stock_test
{
    public partial class WebForm8 : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand cmd;
        string fl = "";
        int flag = 0;
        protected void Page_Load(object sender, EventArgs e)
        {

            Control c = this.Master.FindControl("lbLogin");// "masterDiv"= the Id of the div.
            c.Visible = false;
            Control d = this.Master.FindControl("lbRegster");// "masterDiv"= the Id of the div.
            d.Visible = false;
            Control ee = this.Master.FindControl("LinkButton1");// "masterDiv"= the Id of the div.
            ee.Visible = true;
            Control f = this.Master.FindControl("lbAdminLogin");// "masterDiv"= the Id of the div.
            f.Visible = false;
            string s = ConfigurationManager.AppSettings["constr"];
            con = new SqlConnection(s);
            con.Open();

            ////if (checkuser == "ExistingUser")
            ////{ 

            ////}
            string checkuser = Session["check"].ToString();
            if (checkuser != "ExistingUser")
            {
                fl = "0";
                ViewState["fl"] = fl;
            }
            else
            {
                fl = "2";
                ViewState["fl"] = fl;
            }
            if (!IsPostBack)
            {
                lblUsername.Text = Session["Fname"].ToString();
                lblaccbal.Text = Session["amount"].ToString();

            }


        }

        public void BindSellGrid()
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand("Seller_Grid1", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter da = new SqlDataAdapter();
                    // This will be your input parameter and its value
                    string usr = Session["Userid"].ToString();
                    cmd.Parameters.Add("@Userid", SqlDbType.VarChar).Value = usr;
                    cmd.Parameters.Add("@Exchange_type", SqlDbType.VarChar).Value = ddlexchangetype.SelectedItem.ToString();
                    cmd.Parameters.Add("@Company_symbol", SqlDbType.VarChar).Value = ddlcompanysym.SelectedItem.ToString();



                    da.SelectCommand = cmd;
                    da.SelectCommand.CommandType = CommandType.StoredProcedure;

                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    DataTable dt = new DataTable();
                    DataTable dt1 = new DataTable();
                    if (ds.Tables[0].Rows.Count > 0 && ds.Tables[0].Columns.Count > 1)
                    {
                        flag = 2;
                        ViewState["flag"] = flag;
                        dt = ds.Tables[0];
                        dt1 = ds.Tables[1];
                        lblaccbal.Text = dt1.Rows[0][0].ToString();
                    }
                    else
                    {
                        flag = 1;
                        ViewState["flag"] = flag;
                        lblaccbal.Text = ds.Tables[0].Rows[0][0].ToString();
                        System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('No Shares TO Sell');", true);
                        GridView1.Visible = false;
                        btnsell.Visible = false;
                        btnbuy.Visible = false;
                    }

                    if (dt.Rows.Count == 0)
                    {
                        flag = 1;
                        ViewState["flag"] = flag;
                        System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('No Shares TO Sell');", true);
                        GridView1.Visible = false;
                        btnsell.Visible = false;
                        btnbuy.Visible = false;
                        lblaccbal.Text = ds.Tables[0].Rows[0][0].ToString();
                    }
                    else
                    {
                        flag = 2;
                        ViewState["flag"] = flag;
                        GridView1.DataSource = dt;
                        GridView1.DataBind();
                        lblaccbal.Text = dt1.Rows[0][0].ToString();
                    }


                }

            }

            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }

        }
        public void BindComapnyName()
        {

            try
            {
                using (SqlCommand cmd = new SqlCommand("Get_Company_Names", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter da = new SqlDataAdapter();
                    // This will be your input parameter and its value
                    cmd.Parameters.Add("@Exchangetype", SqlDbType.VarChar).Value = ddlexchangetype.SelectedItem.ToString();



                    da.SelectCommand = cmd;
                    da.SelectCommand.CommandType = CommandType.StoredProcedure;

                    DataSet ds = new DataSet();

                    da.Fill(ds);
                    DataTable dt = new DataTable();

                    dt = ds.Tables[0];
                    ddlcmpname.Items.Clear();
                    ddlcmpname.DataSource = dt;
                    ddlcmpname.DataValueField = "ID";
                    ddlcmpname.DataTextField = "Company_name";
                    ddlcmpname.DataBind();
                    ddlcmpname.Items.Insert(0, new ListItem("--SELECT--", "0"));

                }

            }

            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }

        }


        public void BindCompanySymbol()
        {

            try
            {
                using (SqlCommand cmd = new SqlCommand("Get_Company_Symbols", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter da = new SqlDataAdapter();
                    // This will be your input parameter and its value


                    cmd.Parameters.Add("@Company_name", SqlDbType.VarChar).Value = ddlcmpname.SelectedItem.ToString();

                    da.SelectCommand = cmd;
                    da.SelectCommand.CommandType = CommandType.StoredProcedure;

                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    DataTable dt = new DataTable();

                    dt = ds.Tables[0];
                    ddlcompanysym.Items.Clear();
                    ddlcompanysym.DataSource = dt;
                    ddlcompanysym.DataValueField = "ID";
                    ddlcompanysym.DataTextField = "Company_symbol";
                    ddlcompanysym.DataBind();
                    ddlcompanysym.Items.Insert(0, new ListItem("--SELECT--", "0"));

                }

            }

            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }

        }


        public void BuyerGridBind()
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand("Buyers_Grid", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter da = new SqlDataAdapter();
                    // This will be your input parameter and its value
                    string usr = Session["Userid"].ToString();
                    cmd.Parameters.Add("@Userid", SqlDbType.VarChar).Value = usr;
                    cmd.Parameters.Add("@Exchange_type", SqlDbType.VarChar).Value = ddlexchangetype.SelectedItem.ToString();
                    cmd.Parameters.Add("@Company_symbol", SqlDbType.VarChar).Value = ddlcompanysym.SelectedItem.ToString();



                    da.SelectCommand = cmd;
                    da.SelectCommand.CommandType = CommandType.StoredProcedure;

                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    DataTable dt = new DataTable();
                    DataTable dt1 = new DataTable();

                    dt = ds.Tables[0];
                    dt1 = ds.Tables[1];
                    GridView2.DataSource = dt;
                    GridView2.DataBind();
                    lblaccbal.Text = dt1.Rows[0][0].ToString();
                }

            }

            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }

        }

        protected void ddlexchangetype_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlexchangetype.SelectedItem.ToString() == "--SELECT--")
            {
                ddlcompanysym.SelectedIndex = 0;
                ddlcmpname.SelectedIndex = 0;
            }
            // ddlcompanysym.Items.Insert(0, new ListItem("--SELECT--", "0"));
            BindComapnyName();
            GridView2.Visible = false;
        }

        protected void ddlcmpname_SelectedIndexChanged(object sender, EventArgs e)
        {
            // ddlcompanysym.SelectedIndex = 0;
            if (ddlcmpname.SelectedItem.ToString() == "--SELECT--")
            {
                ddlcompanysym.SelectedIndex = 0;
                //ddlexchangetype.SelectedIndex = 0;
                ddlcmpname.Items.Clear();
                ddlcompanysym.Items.Clear();
                //ddlcmpname.Items.Insert(0, new ListItem("--SELECT--", "0"));
                //ddlcompanysym.Items.Insert(0, new ListItem("--SELECT--", "0"));
            }
            if (ddlexchangetype.SelectedItem.ToString() != "--SELECT--" && ddlcmpname.SelectedItem.ToString() != "--SELECT--")
            {
                BindCompanySymbol();
            }
            GridView2.Visible = false;
        }


        protected void btnget_details_Click(object sender, EventArgs e)
        {
            GridView2.Visible = true;
            BuyerGridBind();
            btnbuy.Visible = true;
            GridView1.Visible = false;
            btnsell.Visible = false;
        }

        protected void ddlcompanysym_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlcompanysym.SelectedItem.ToString() == "--SELECT--")
            {
                //ddlcmpname.SelectedIndex = 0;
                //ddlexchangetype.SelectedIndex = 0;
                ddlcompanysym.Items.Clear();
                ddlcompanysym.Items.Insert(0, new ListItem("--SELECT--", "0"));
            }
            if (ddlexchangetype.SelectedItem.ToString() != "--SELECT--" && ddlcmpname.SelectedItem.ToString() != "--SELECT--" && ddlcompanysym.SelectedItem.ToString() != "--SELECT--")
            {
                btnget_details.Enabled = true;
                Button1.Enabled = true;
            }
            GridView2.Visible = false;

        }

        protected void btnbuy_Click(object sender, EventArgs e)
        {
            Label lblcmpname, lblcmpsym, lblexchangetype, lblopeningprice, lblclosing_price, lblno_of_shares, lblshare_price,
                lblPrevious_Sell_Price, lblPrevious_Buy_Price;
            string ttlamountshare = "";
            string lbno_of_shares = "";
            string lbshareprice = "";
            // ArrayList checkedItems = new ArrayList();
            try
            {
                for (int i = 0; i < GridView2.Rows.Count; i++)
                {
                    //string id = GridView1.Rows[i].["Company Name"].ToString();
                    lblcmpname = (Label)GridView2.Rows[i].FindControl("lblCompany_name");
                    lblcmpsym = (Label)GridView2.Rows[i].FindControl("lblCompany_symbol");
                    lblexchangetype = (Label)GridView2.Rows[i].FindControl("lblExchange_type");
                    lblopeningprice = (Label)GridView2.Rows[i].FindControl("lblopening_price");
                    lblclosing_price = (Label)GridView2.Rows[i].FindControl("lblclosing_price");

                    lblno_of_shares = (Label)GridView2.Rows[i].FindControl("lblno_of_shares");
                    lbno_of_shares = lblno_of_shares.Text;
                    lblshare_price = (Label)GridView2.Rows[i].FindControl("lblshare_price");
                    lbshareprice = lblshare_price.Text;
                    lblPrevious_Buy_Price = (Label)GridView2.Rows[i].FindControl("lblPrevious_Buy_Price");

                    lblPrevious_Sell_Price = (Label)GridView2.Rows[i].FindControl("lblPrevious_Sell_Price");
                    TextBox txtamountofshares = (TextBox)GridView2.Rows[i].FindControl("txt_no_of_shares_to_buy");
                    ttlamountshare = txtamountofshares.Text;
                }

                double totalshareprice = ((Convert.ToInt32(ttlamountshare)) * (Convert.ToDouble(lbshareprice)));
                double brokeramt = 0.1 * (totalshareprice);
                using (SqlCommand cmd = new SqlCommand("Insertion_Buyers_Grid1", con))
                {

                    cmd.CommandType = CommandType.StoredProcedure;
                    //cmd.Parameters.Add("@flagchecker", "0");
                    Int64 acc_no = Convert.ToInt64(Session["Acc_no"]);
                    Int64 amount = Convert.ToInt64(Session["amount"]);
                    //cmd.Parameters.Add("@Userid", Session["Userid"].ToString());
                    cmd.Parameters.Add("@Userid", SqlDbType.VarChar).Value = Session["Userid"].ToString();
                    cmd.Parameters.Add("@Acc_no", SqlDbType.BigInt).Value = acc_no;
                    cmd.Parameters.Add("@Amount", SqlDbType.BigInt).Value = amount;
                    cmd.Parameters.Add("@Exchange_type", SqlDbType.VarChar).Value = ddlexchangetype.SelectedItem.ToString();
                    cmd.Parameters.Add("@Company_symbol", SqlDbType.VarChar).Value = ddlcompanysym.SelectedItem.ToString();
                    cmd.Parameters.Add("@Company_name", SqlDbType.VarChar).Value = ddlcmpname.SelectedItem.ToString();
                    cmd.Parameters.Add("@no_of_shares", SqlDbType.Int).Value = Convert.ToInt32(ttlamountshare);
                    cmd.Parameters.Add("@date_", SqlDbType.DateTime).Value = DateTime.Now;
                    cmd.Parameters.Add("@share_price", SqlDbType.Float).Value = Convert.ToDouble(lbshareprice);
                    cmd.Parameters.Add("@broker_amount", SqlDbType.Float).Value = brokeramt;
                    cmd.Parameters.Add("@total_share_price", SqlDbType.Float).Value = totalshareprice;
                    cmd.Parameters.Add("@transtype", SqlDbType.VarChar).Value = "1";


                    SqlParameter returnParameter = cmd.Parameters.Add("RetVal", SqlDbType.Int);
                    returnParameter.Direction = ParameterDirection.ReturnValue;
                    Int64 ushare = Convert.ToInt64(ttlamountshare);
                    Int64 cshare = Convert.ToInt64(lbno_of_shares);
                    Int64 accbal = Convert.ToInt64(lblaccbal.Text);
                    if (ushare == 0)
                    {
                        System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('Shares Cannot Be Zero');", true);
                        TextBox txtamountofshares1 = (TextBox)GridView2.Rows[0].FindControl("txt_no_of_shares_to_buy");
                        txtamountofshares1.Text = "";
                        txtamountofshares1.Focus();
                    }
                    else
                    {

                        if (ushare > cshare || (totalshareprice + brokeramt) > accbal)
                        {
                            System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('You exceeded Share Quantity');", true);
                            TextBox txtamountofshares1 = (TextBox)GridView2.Rows[0].FindControl("txt_no_of_shares_to_buy");
                            txtamountofshares1.Text = "";
                            txtamountofshares1.Focus();
                        }
                        else
                        {
                            cmd.ExecuteNonQuery();

                            int id = (int)returnParameter.Value;
                            if (id == 0)
                            {
                                System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('Shares Purchased');", true);
                                BuyerGridBind();
                                GridView2.Visible = false;
                                btnbuy.Visible = false;
                                BindSellGrid();
                                GridView2.Visible = false;
                                btnsell.Visible = false;
                                fl = "1";
                                ViewState["fl"] = fl;
                                Session["check"] = "ExistingUser";

                            }

                        }
                    }
                }

            }
            catch (Exception ex)
            {

                throw (ex);
            }
        }

        protected void btnsell_Click(object sender, EventArgs e)
        {
            string ttlamountshare = "";
            string lbno_of_shares = "";
            string lbshareprice = "";
            try
            {
                for (int i = 0; i < GridView1.Rows.Count; i++)
                {
                    Label lblCompany_name1 = (Label)GridView1.Rows[i].FindControl("lblCompany_name1");
                    Label lblCompany_symbol1 = (Label)GridView1.Rows[i].FindControl("lblCompany_symbol1");
                    Label lblExchange_type1 = (Label)GridView1.Rows[i].FindControl("lblExchange_type1");
                    Label lblno_of_shares1 = (Label)GridView1.Rows[i].FindControl("lblno_of_shares1");
                    lbno_of_shares = (lblno_of_shares1.Text);
                    Label lblPrevious_buy_price1 = (Label)GridView1.Rows[i].FindControl("lblPrevious_buy_price1");
                    Label lblPrevious_Sell_Price1 = (Label)GridView1.Rows[i].FindControl("lblPrevious_Sell_Price1");
                    Label lblCurrentShareSellPrice = (Label)GridView1.Rows[i].FindControl("lblCurrentShareSellPrice");
                    lbshareprice = lblCurrentShareSellPrice.Text;
                    TextBox txt_no_of_shares_to_sell = (TextBox)GridView1.Rows[i].FindControl("txt_no_of_shares_to_sell");
                    ttlamountshare = txt_no_of_shares_to_sell.Text;
                }
                double totalshareprice = ((Convert.ToInt32(ttlamountshare)) * (Convert.ToDouble(lbshareprice)));
                double brokeramt = 0.1 * totalshareprice;

                using (SqlCommand cmd = new SqlCommand("Insertion_Sell_Grid1", con))
                {

                    cmd.CommandType = CommandType.StoredProcedure;
                    //cmd.Parameters.Add("@flagchecker", "0");
                    Int64 acc_no = Convert.ToInt64(Session["Acc_no"]);
                    Int64 amount = Convert.ToInt64(Session["amount"]);
                    //cmd.Parameters.Add("@Userid", Session["Userid"].ToString());
                    cmd.Parameters.Add("@Userid", SqlDbType.VarChar).Value = Session["Userid"].ToString();
                    cmd.Parameters.Add("@Acc_no", SqlDbType.BigInt).Value = acc_no;
                    cmd.Parameters.Add("@Amount", SqlDbType.BigInt).Value = Convert.ToInt64(lblaccbal.Text);
                    cmd.Parameters.Add("@Exchange_type", SqlDbType.VarChar).Value = ddlexchangetype.SelectedItem.ToString();
                    cmd.Parameters.Add("@Company_symbol", SqlDbType.VarChar).Value = ddlcompanysym.SelectedItem.ToString();
                    cmd.Parameters.Add("@Company_name", SqlDbType.VarChar).Value = ddlcmpname.SelectedItem.ToString();
                    cmd.Parameters.Add("@no_of_shares", SqlDbType.Int).Value = Convert.ToInt32(ttlamountshare);
                    cmd.Parameters.Add("@date_", SqlDbType.DateTime).Value = DateTime.Now;
                    cmd.Parameters.Add("@share_price", SqlDbType.Float).Value = Convert.ToDouble(lbshareprice);
                    cmd.Parameters.Add("@broker_amount", SqlDbType.Float).Value = brokeramt;
                    cmd.Parameters.Add("@total_share_price", SqlDbType.Float).Value = totalshareprice;
                    cmd.Parameters.Add("@transtype", SqlDbType.VarChar).Value = "2";


                    SqlParameter returnParameter = cmd.Parameters.Add("RetVal", SqlDbType.Int);
                    returnParameter.Direction = ParameterDirection.ReturnValue;
                    Int64 ushare = Convert.ToInt64(ttlamountshare);
                    Int64 cshare = Convert.ToInt64(lbno_of_shares);
                    Int64 accbal = Convert.ToInt64(lblaccbal.Text);
                    if (ushare == 0)
                    {
                        System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('Shares Cannot Be Zero');", true);
                        TextBox txtamountofshares1 = (TextBox)GridView1.Rows[0].FindControl("txt_no_of_shares_to_sell");
                        txtamountofshares1.Text = "";
                        txtamountofshares1.Focus();
                    }
                    else
                    {
                        if (ushare > cshare)
                        {
                            System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('You exceeded Share Quantity');", true);
                            TextBox txtamountofshares1 = (TextBox)GridView1.Rows[0].FindControl("txt_no_of_shares_to_sell");
                            txtamountofshares1.Text = "";
                            txtamountofshares1.Focus();
                        }
                        else
                        {
                            cmd.ExecuteNonQuery();

                            int id = (int)returnParameter.Value;
                            if (id == 0)
                            {
                                System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('Shares sold');", true);
                                BindSellGrid();
                                GridView2.Visible = false;
                                btnbuy.Visible = false;


                            }


                        }
                    }

                }


            }
            catch (Exception ex)
            {

                throw (ex);
            }

        }



        protected void Button1_Click(object sender, EventArgs e)
        {
            GridView2.Visible = false;
            btnbuy.Visible = false;

            //btnget_details.en
            string checkuser = Session["check"].ToString();
            string fm = ViewState["fl"].ToString();
            if (checkuser == "ExistingUser" || fm == "1")
            {
                int fg = Convert.ToInt16(ViewState["flag"]);
                if (fg == 0)
                {
                    BindSellGrid();
                    fg = Convert.ToInt16(ViewState["flag"]);
                    if (fg == 1)
                    {
                        System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('No Shares are there to sell');", true);
                        btnsell.Visible = false;
                    }
                    else
                    {
                        btnsell.Visible = true;
                    }
                }

                if (fg == 2)
                {
                    BindSellGrid();
                    GridView1.Visible = true;
                    GridView2.Visible = false;
                    btnsell.Visible = true;

                }
                if (fg == 1)
                {
                    System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('No Shares are there to sell');", true);
                    btnsell.Visible = false;
                }

            }
            else
            {
                GridView2.Visible = false;
                btnbuy.Visible = false;
                System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('No Shares are there to sell');", true);
            }
        }
    }

}
