﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Stock_test
{
    public partial class WebForm10 : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {
            string s = ConfigurationManager.AppSettings["constr"];
            con = new SqlConnection(s);
            con.Open();
            if (!IsPostBack)
            {
                BindCompanySymbol();
            }
        }
        public void BindCompanySymbol()
        {

            try
            {
                using (SqlCommand cmd = new SqlCommand("Get_Nasdaq_Company_Symbols", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter da = new SqlDataAdapter();
                    // This will be your input parameter and its value


                    //   cmd.Parameters.Add("@Company_name", SqlDbType.VarChar).Value = ddlcmpname.SelectedItem.ToString();

                    da.SelectCommand = cmd;
                    da.SelectCommand.CommandType = CommandType.StoredProcedure;

                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    DataTable dt = new DataTable();

                    dt = ds.Tables[0];
                    ddlcompanysym.Items.Clear();
                    ddlcompanysym.DataSource = dt;
                    ddlcompanysym.DataValueField = "ID";
                    ddlcompanysym.DataTextField = "Company_symbol";
                    ddlcompanysym.DataBind();
                    ddlcompanysym.Items.Insert(0, new ListItem("--SELECT--", "0"));

                }

            }

            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }

        }

    }
}