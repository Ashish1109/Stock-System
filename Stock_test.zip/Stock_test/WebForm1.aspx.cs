﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Stock_test
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {
            Page.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            string s = ConfigurationManager.AppSettings["constr"];
            con = new SqlConnection(s);
            con.Open();
        }

        protected void btn_submit_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand("Insert_User_Registration_Details", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                   
                    cmd.Parameters.Add("@flagchecker", SqlDbType.VarChar).Value = "0";
                    cmd.Parameters.Add("@F_name", SqlDbType.VarChar).Value = txt_Fname.Text;
                    cmd.Parameters.Add("@L_name", SqlDbType.VarChar).Value = txt_lname.Text;
                    cmd.Parameters.Add("@Userid", SqlDbType.VarChar).Value = txt_Userid.Text;
                    cmd.Parameters.Add("@userpassword", SqlDbType.VarChar).Value = txt_cnrm_psswrd.Text;
                    cmd.Parameters.Add("@Acc_no", SqlDbType.BigInt).Value = Convert.ToInt64(txt_aacno.Text);
                    cmd.Parameters.Add("@Acc_type", SqlDbType.VarChar).Value = txtAccount_type.Text;
                    cmd.Parameters.Add("@Amount", SqlDbType.BigInt).Value = Convert.ToInt64(txt_amount.Text);
                    cmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = txt_address.Text;
                    cmd.Parameters.Add("@CITY", SqlDbType.VarChar).Value = txt_city.Text;
                    cmd.Parameters.Add("@STATE", SqlDbType.VarChar).Value = txt_state.Text;
                    cmd.Parameters.Add("@COUNTRY", SqlDbType.VarChar).Value = txt_country.Text;
                    cmd.Parameters.Add("@ZIP", SqlDbType.BigInt).Value = Convert.ToInt64(txt_zip.Text);
                    cmd.Parameters.Add("@dob", SqlDbType.VarChar).Value = txt_dob.Text;
                    cmd.Parameters.Add("@Ph_no", SqlDbType.BigInt).Value = Convert.ToInt64(txt_phno.Text);
                    cmd.Parameters.Add("@Email_id", SqlDbType.VarChar).Value = txt_email.Text;
                    cmd.Parameters.Add("@Login_Date_time", SqlDbType.DateTime).Value = DateTime.Now;
                   
                    SqlParameter returnParameter = cmd.Parameters.Add("RetVal", SqlDbType.Int);
                    returnParameter.Direction = ParameterDirection.ReturnValue;
                    cmd.ExecuteNonQuery();

                    int id = (int)returnParameter.Value;
                    if (id == 0)
                    {
                        System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('Registered Successfully');", true);
                        Response.Redirect("home.aspx");
                    }
                    if (id == 1)
                    {
                        System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('Updated Successfully');", true);
                    }
                    con.Close();
                    
                }
            }
            catch (Exception ex)
                {
                    
            throw (ex);
                }
        }

        protected void btn_cancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("home.aspx");
        }
    }
}