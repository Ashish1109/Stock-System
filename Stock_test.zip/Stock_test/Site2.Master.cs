﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Stock_test
{
    public partial class Site2 : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void lbAdminLogin_Click(object sender, EventArgs e)
        {
            Response.Redirect("Adminlogin.aspx");
        }
        protected void lbLogin_Click(object sender, EventArgs e)
        {
            Response.Redirect("LoginPage.aspx");
        }
        protected void lbRegster_Click(object sender, EventArgs e)
        {
            Response.Redirect("Register.aspx");
        }
        protected void lnLogout_Click(object sender, EventArgs e)
        {
            Response.Redirect("logout.aspx");
        }
    }
}