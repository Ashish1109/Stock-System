﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Stock_test
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {
            Control c = this.Master.FindControl("lbLogin");// "masterDiv"= the Id of the div.
            c.Visible = false;
            Control d = this.Master.FindControl("lbRegster");// "masterDiv"= the Id of the div.
            d.Visible = false;
            Control f = this.Master.FindControl("lbAdminLogin");// "masterDiv"= the Id of the div.
            f.Visible = false;
            Control ee = this.Master.FindControl("LinkButton1");// "masterDiv"= the Id of the div.
            ee.Visible = true;
            string s = ConfigurationManager.AppSettings["constr"];
            con = new SqlConnection(s);
            con.Open();

            if (!IsPostBack)
            {
                lblUsername.Text = "Admin";
                BindGrid();
            }
        }


        protected void lbdelete_Click(object sender, EventArgs e)
        {
            int rowIndex = Convert.ToInt16(((GridViewRow)((Control)sender).NamingContainer).RowIndex);
            Label userid = (Label)GridView2.Rows[rowIndex].FindControl("lbluserid");
            try
            {
                using (SqlCommand cmd = new SqlCommand("Admin_Delete_Users", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;


                    cmd.Parameters.Add("@Userid", SqlDbType.VarChar).Value = userid.Text;

                    SqlParameter returnParameter = cmd.Parameters.Add("RetVal", SqlDbType.Int);
                    returnParameter.Direction = ParameterDirection.ReturnValue;
                    cmd.ExecuteNonQuery();
                    BindGrid();
                    int id = (int)returnParameter.Value;



                }
            }
            catch (Exception ex)
            {

                throw (ex);
            }
        }

        protected void DeleteRow(object sender, GridViewDeleteEventArgs e)
        {
            int index = Convert.ToInt16(GridView2.DataKeys[e.RowIndex].Value);
            Label userid = (Label)GridView2.Rows[index].FindControl("lbluserid");
            try
            {
                using (SqlCommand cmd = new SqlCommand("Admin_Delete_Users", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;


                    cmd.Parameters.Add("@Userid", SqlDbType.VarChar).Value = userid.Text;

                    SqlParameter returnParameter = cmd.Parameters.Add("RetVal", SqlDbType.Int);
                    returnParameter.Direction = ParameterDirection.ReturnValue;
                    cmd.ExecuteNonQuery();
                    BindGrid();
                    int id = (int)returnParameter.Value;



                }
            }
            catch (Exception ex)
            {

                throw (ex);
            }
        }

        public void BindGrid()
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand("Admin_Alll_User_id", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter da = new SqlDataAdapter();
                    // This will be your input parameter and its value
                    da.SelectCommand = cmd;
                    da.SelectCommand.CommandType = CommandType.StoredProcedure;
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    DataTable dt = new DataTable();
                    DataTable dt1 = new DataTable();

                    if (ds.Tables[1].Rows.Count > 0)
                    {
                        dt1 = ds.Tables[1];
                        lblaccbal.Text = dt1.Rows[0][0].ToString();
                    }
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        dt = ds.Tables[0];
                        dt1 = ds.Tables[1];
                        lblaccbal.Text = dt1.Rows[0][0].ToString();
                        GridView2.DataSource = dt;
                        GridView2.DataBind();
                    }
                    if (ds.Tables[0].Rows.Count < 1 || ds.Tables[0] == null)
                    {
                        System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('No Users To Show');", true);
                        GridView2.Visible = false;
                        lblaccbal.Text = "0.0";
                    }

                }

            }

            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }

        }
    
}
}